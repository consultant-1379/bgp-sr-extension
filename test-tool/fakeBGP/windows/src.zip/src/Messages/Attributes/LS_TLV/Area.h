/*
 * Area.h
 *
 *  Created on: Oct 28, 2014
 *      Author: egboeny
 */

#ifndef AREA_H_
#define AREA_H_

#include "LSTLV.h"

class Area: public LSTLV {
public:
    Area(uint32_t area);
	virtual ~Area();
};

#endif /* AREA_H_ */

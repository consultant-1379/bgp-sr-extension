/*
 * LocalNodeDescriptor.cpp
 *
 *  Created on: Feb 11, 2014
 *      Author: egboeny
 */

#include "NodeDescriptor.h"

LocalNodeDescriptor::LocalNodeDescriptor() : LSTLV(256) {
}

LocalNodeDescriptor::~LocalNodeDescriptor() {
	// TODO Auto-generated destructor stub
}

RemoteNodeDescriptor::RemoteNodeDescriptor() : LSTLV(257) {
}

RemoteNodeDescriptor::~RemoteNodeDescriptor() {
	// TODO Auto-generated destructor stub
}


/*
 * SIDLabelBinding.cpp
 *
 *  Created on: Mar 6, 2014
 *      Author: egboeny
 */

#include "SIDLabelBinding.h"

SIDLabelBinding::SIDLabelBinding() : LSTLV(1033) {
	// TODO Auto-generated constructor stub

	throw;	//NOT READY YET!
}

SIDLabelBinding::~SIDLabelBinding() {
	// TODO Auto-generated destructor stub
}


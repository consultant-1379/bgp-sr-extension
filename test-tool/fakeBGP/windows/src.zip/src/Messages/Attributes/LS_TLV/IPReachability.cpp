/*
 * IPReachability.cpp
 *
 *  Created on: Oct 25, 2014
 *      Author: enyedi
 */

#include "IPReachability.h"

#include <math.h>

IPReachability::IPReachability(const boost::asio::ip::address_v4& address, const uint8_t len) : LSTLV(265) {
    setLength(1 + ceil(len/8));

    *data.value = len;
    *((uint32_t*)(data.value+1)) = htonl(address.to_ulong());
}

IPReachability::~IPReachability() {
    // TODO Auto-generated destructor stub
}


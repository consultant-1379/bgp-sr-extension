/*
 * ExtendedCommunity.cpp
 *
 *  Created on: Feb 7, 2014
 *      Author: egboeny
 */

#include "ExtendedCommunity.h"

ExtendedCommunity::ExtendedCommunity(const VRD& vrd) {
	// TODO Auto-generated constructor stub

	throw;	//NOT READY YET!
}

ExtendedCommunity::~ExtendedCommunity() {
	// TODO Auto-generated destructor stub
}


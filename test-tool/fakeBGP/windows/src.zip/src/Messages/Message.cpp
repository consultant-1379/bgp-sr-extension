/*
 * Message.cpp
 *
 *  Created on: Feb 5, 2014
 *      Author: egboeny
 */

#include "Message.h"

Message::Message() {
	// TODO Auto-generated constructor stub

}

Message::~Message() {
	// TODO Auto-generated destructor stub
}


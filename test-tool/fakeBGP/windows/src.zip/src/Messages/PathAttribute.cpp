/*
 * PathAttribute.cpp
 *
 *  Created on: Feb 7, 2014
 *      Author: egboeny
 */

#include "PathAttribute.h"

PathAttribute::PathAttribute() {
	// TODO Auto-generated constructor stub

}

PathAttribute::~PathAttribute() {
	// TODO Auto-generated destructor stub
}


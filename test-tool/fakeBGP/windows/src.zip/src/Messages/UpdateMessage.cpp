/*
 * UpdateMessage.cpp
 *
 *  Created on: Feb 5, 2014
 *      Author: egboeny
 */

#include "UpdateMessage.h"

UpdateMessage::UpdateMessage() {
}

UpdateMessage::~UpdateMessage() {
	// TODO Auto-generated destructor stub
}


/*
 * OpenMessage.cpp
 *
 *  Created on: Feb 5, 2014
 *      Author: egboeny
 */

#include "OpenMessage.h"
#include <string.h>

OpenMessage::OpenMessage() {
StaticMessage binary_message =  {0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, //Init
			 	 	 	 	     0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
			 	 	 	 	 	 //55 byte |open | BGPv4| AS: 6666 | Hold Time:180
			 	 	 	 	 	 0x00, 0x3d, 0x01, 0x04, 0x1a, 0x0a, 0x00, 0xb4,
			 	 	 	 	 	 //id:172.31.32.15 |opt:32B|
			 	 	 	 	 	 0xac, 0x1f, 0x20, 0x0f, 0x20,
			 	 	 	 	     //Cap=2|len=6|type=4BAS|len=4B|AS=6666
			 	 	 	 	 	 0x02, 0x06,     0x41,     0x04, 0x00, 0x00, 0x1a, 0x0a,
			 	 	 	 	 	 //Cap=2|len=6|MultExt|len=4B|AFI=1(IPv4)|reserved| SAFI=1(unicast)
			 	 	 	 	 	 0x02, 0x06,     0x01,  0x04, 0x00, 0x01,  0x00,    0x01,
			 	 	 	 	 	 //Cap=2|len=6|MultExt|len=4B|AFI=1(IPv6)|reserved| SAFI=1(unicast)
			 	 	 	 	 	 0x02, 0x06,     0x01,  0x04, 0x00, 0x02,  0x00,    0x01,
			 	 	 	 	 	 //Cap=2|len=6|MultExt|len=4B|AFI=16388(BGP-LS)|reserved| SAFI=71(non-VPN)
			 	 	 	 	 	 0x02, 0x06,     0x01,  0x04,    0x40, 0x04,      0x00,    0x47};

memcpy(this->binary_message, binary_message, sizeof(StaticMessage));
}

OpenMessage::~OpenMessage() {
	// TODO Auto-generated destructor stub
}


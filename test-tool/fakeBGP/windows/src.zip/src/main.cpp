/*
 * main.cpp
 *
 *  Created on: Feb 5, 2014
 *      Author: egboeny
 */

#include "FakeBGPLS.h"
#include <iostream>
#include <cstdlib>

/*static std::string getHome() {
    char buf[2048];
    ssize_t len = readlink("/proc/self/exe", buf, sizeof(buf)-1);
    if (len == -1) {
        std::cerr << "Error reading /proc" << std::endl;
        std::exit(-1);
    }
    buf[len] = '\0';
    std::string home(buf);

    return home.substr(0, home.find_last_of("/\\"));
}*/

int main(int argc, char* argv[]) {
	if (argc < 2)
		return -1;
	try {
		//return FakePlainBGP(argv[1]).run();
		return FakeBGPLS(argv[1]).run();
	} catch (std::string& str) {
		std::cout << "Finished with exception. Reason: " << str << std::endl;
	}

	return -1;
}
